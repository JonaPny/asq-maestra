<?php
$page_title = "Dashboard - Salon Admin";
include 'components/header.php';
include 'components/sidebar.php';
include 'components/navbar.php';

// Include database connection
include '../login_register/tools/salondb.php';
$conn = getAdminDatabaseConnection();

// Check if the database tables exist, if not create them
$result = $conn->query("SHOW TABLES LIKE 'calendar_settings'");
if ($result->num_rows == 0) {
    include 'includes/create_tables.php';
}

// Get current month and year
$month = isset($_GET['month']) ? intval($_GET['month']) : date('n');
$year = isset($_GET['year']) ? intval($_GET['year']) : date('Y');

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        // Update day status
        if ($_POST['action'] === 'update_day') {
            $date = $_POST['date'];
            $status = $_POST['status'];
            $notes = $_POST['notes'];
            
            // If status is 'default', delete any existing record for this date
            if ($status === 'default') {
                $stmt = $conn->prepare("DELETE FROM calendar_settings WHERE date = ?");
                $stmt->bind_param("s", $date);
                $success = $stmt->execute();
                $error_message = $stmt->error;
                $stmt->close();
            } else {
                // Check if a record already exists for this date
                $check_stmt = $conn->prepare("SELECT id FROM calendar_settings WHERE date = ?");
                $check_stmt->bind_param("s", $date);
                $check_stmt->execute();
                $check_result = $check_stmt->get_result();
                
                if ($check_result->num_rows > 0) {
                    // Update existing record
                    $row = $check_result->fetch_assoc();
                    $id = $row['id'];
                    $stmt = $conn->prepare("UPDATE calendar_settings SET status = ?, notes = ? WHERE id = ?");
                    $stmt->bind_param("ssi", $status, $notes, $id);
                } else {
                    // Insert new record
                    $stmt = $conn->prepare("INSERT INTO calendar_settings (date, status, notes) VALUES (?, ?, ?)");
                    $stmt->bind_param("sss", $date, $status, $notes);
                }
                
                $success = $stmt->execute();
                $error_message = $stmt->error;
                $stmt->close();
                $check_stmt->close();
            }
            
            // If it's an AJAX request, return JSON response
            if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
                header('Content-Type: application/json');
                if ($success) {
                    echo json_encode(['success' => true, 'message' => "Day status updated successfully!"]);
                } else {
                    echo json_encode(['success' => false, 'message' => "Error updating day status: " . $error_message]);
                }
                exit;
            } else if ($success) {
                $success_message = "Day status updated successfully!";
            } else {
                $error_message = "Error updating day status: " . $error_message;
            }
        }
    }
}

// Get calendar settings for the month
$calendar_settings = [];
$first_day = sprintf('%04d-%02d-01', $year, $month);
$last_day = date('Y-m-t', strtotime($first_day));

$stmt = $conn->prepare("SELECT date, status, notes FROM calendar_settings WHERE date BETWEEN ? AND ?");
$stmt->bind_param("ss", $first_day, $last_day);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $calendar_settings[$row['date']] = [
        'status' => $row['status'],
        'notes' => $row['notes']
    ];
}
$stmt->close();

// Get appointment counts for the month
$appointments = [];
$stmt = $conn->prepare("SELECT appointment_date, COUNT(*) as count, service_type FROM appointments WHERE appointment_date BETWEEN ? AND ? GROUP BY appointment_date, service_type");
$stmt->bind_param("ss", $first_day, $last_day);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $date = $row['appointment_date'];
    
    if (!isset($appointments[$date])) {
        $appointments[$date] = [
            'count' => 0,
            'type' => ''
        ];
    }
    
    $appointments[$date]['count'] += $row['count'];
    
    // Determine type based on majority
    if ($row['service_type'] === 'home') {
        $appointments[$date]['type'] = 'home-service';
    } else {
        $appointments[$date]['type'] = 'salon-service';
    }
}
$stmt->close();

// Month names for display
$month_names = [
    1 => "JANUARY", 2 => "FEBRUARY", 3 => "MARCH", 4 => "APRIL",
    5 => "MAY", 6 => "JUNE", 7 => "JULY", 8 => "AUGUST",
    9 => "SEPTEMBER", 10 => "OCTOBER", 11 => "NOVEMBER", 12 => "DECEMBER"
];

// Get today's date for highlighting - use current server time to ensure it's up-to-date
$today_date = date('Y-m-d', time());

?>

<div class="p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="text-uppercase" id="current-month"><?php echo $month_names[$month] . " " . $year; ?></h2>
        <div class="d-flex align-items-center">
            <a href="?month=<?php echo $month == 1 ? 12 : $month - 1; ?>&year=<?php echo $month == 1 ? $year - 1 : $year; ?>" class="btn btn-sm btn-outline-secondary me-2" id="prev-month">
                <i class="bi bi-chevron-left"></i>
            </a>
            <a href="?month=<?php echo date('n'); ?>&year=<?php echo date('Y'); ?>" class="btn btn-sm btn-outline-secondary me-2" id="today-btn">Today</a>
            <a href="?month=<?php echo $month == 12 ? 1 : $month + 1; ?>&year=<?php echo $month == 12 ? $year + 1 : $year; ?>" class="btn btn-sm btn-outline-secondary me-3" id="next-month">
                <i class="bi bi-chevron-right"></i>
            </a>
            <div class="form-check form-switch me-3">
                <input class="form-check-input" type="checkbox" id="edit-mode">
                <label class="form-check-label" for="edit-mode">Edit Mode</label>
            </div>
        </div>
    </div>

    <div class="alert alert-success d-none" id="calendar-message"></div>

    <div class="calendar-legend mb-3">
        <div class="d-flex align-items-center">
            <div class="legend-item me-3">
                <span class="legend-color day-off"></span>
                <span>DAY OFF</span>
            </div>
            <div class="legend-item me-3">
                <span class="legend-color home-service"></span>
                <span>HOME SERVICE</span>
            </div>
            <div class="legend-item me-3">
                <span class="legend-color salon-service"></span>
                <span>SALON SERVICE</span>
            </div>
            <div class="legend-item">
                <span class="legend-color full-sched"></span>
                <span>FULL SCHED</span>
            </div>
        </div>
    </div>

    <div class="calendar-container">
        <table class="table table-bordered calendar-table">
            <thead>
                <tr>
                    <th>Sun</th>
                    <th>Mon</th>
                    <th>Tue</th>
                    <th>Wed</th>
                    <th>Thu</th>
                    <th>Fri</th>
                    <th>Sat</th>
                </tr>
            </thead>
            <tbody id="calendar-body">
                <?php
                // Generate calendar
                $firstDay = new DateTime("$year-$month-01");
                $lastDay = new DateTime($firstDay->format('Y-m-t'));
                $daysInMonth = intval($lastDay->format('d'));
                $startingDay = intval($firstDay->format('w')); // 0 (Sunday) to 6 (Saturday)

                $date = 1;
                for ($i = 0; $i < 6; $i++) {
                    echo "<tr>";
                    
                    for ($j = 0; $j < 7; $j++) {
                        if ($i === 0 && $j < $startingDay) {
                            // Empty cells before the first day
                            echo "<td></td>";
                        } else if ($date > $daysInMonth) {
                            // Empty cells after the last day
                            echo "<td></td>";
                        } else {
                            // Create date cell
                            $dateStr = sprintf('%04d-%02d-%02d', $year, $month, $date);
                            $cellClass = '';
                            
                            // Check if this date has a special status in calendar_settings
                            if (isset($calendar_settings[$dateStr])) {
                                if ($calendar_settings[$dateStr]['status'] === 'full') {
                                    $cellClass = 'full-sched'; 
                                } else if ($calendar_settings[$dateStr]['status'] === 'salon') {
                                    $cellClass = 'salon-service';
                                } else if ($calendar_settings[$dateStr]['status'] === 'day-off') {
                                    $cellClass = 'day-off';
                                } else if ($calendar_settings[$dateStr]['status'] === 'home') {
                                    $cellClass = 'home-service';
                                }
                            }
                            // Otherwise, check if it has appointments
                            else if (isset($appointments[$dateStr])) {
                                $cellClass = $appointments[$dateStr]['type'];
                            }
                            // If it's Sunday and doesn't have a status yet, mark as day-off
                            else if ($j === 0) {
                                $cellClass = 'day-off';
                            }
                            
                            // Add today class if this is today's date
                            if ($dateStr === $today_date) {
                                $cellClass .= ' today';
                            }
                            
                            // Special case for May 4, 2025 (make it a day off)
                            if ($dateStr === '2025-05-04') {
                                $cellClass = 'day-off';
                            }
                            
                            echo "<td class=\"$cellClass\" data-date=\"$dateStr\" data-day=\"$j\">";
                            echo "<div class=\"calendar-date\">$date</div>";
                            
                            // Add appointment count if any
                            if (isset($appointments[$dateStr]) && $appointments[$dateStr]['count'] > 0) {
                                echo "<span class=\"appointment-count\">{$appointments[$dateStr]['count']}</span>";
                            }
                            
                            echo "</td>";
                            
                            $date++;
                        }
                    }
                    
                    echo "</tr>";
                    
                    // Stop if we've reached the end of the month
                    if ($date > $daysInMonth) {
                        break;
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'components/modals/day_edit_modal.php'; ?>

<!-- Include the separated JavaScript file -->
<script src="assets/js/dashboard.js"></script>

<?php 
// Close the database connection
if ($conn && $conn->ping()) {
    $conn->close();
}
include 'components/footer.php'; ?>
