<?php
// Redirect to the centralized login page
header("Location: ../login_register/login.php");
exit;
?>
