<?php
$page_title = "Appointments - Salon Admin";
include 'components/header.php';
include 'components/sidebar.php';
include 'components/navbar.php';

// Include database connection
include '../login_register/tools/salondb.php';
$conn = getDatabaseConnection();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        // Update appointment status
        if ($_POST['action'] === 'update_status') {
            $id = $_POST['appointment_id'];
            $status = $_POST['status'];
            $notes = $_POST['notes'];
            
            $stmt = $conn->prepare("UPDATE appointments SET status = ?, notes = ?, updated_at = NOW() WHERE id = ?");
            $stmt->bind_param("ssi", $status, $notes, $id);
            $stmt->execute();
            $stmt->close();
            
            $success_message = "Appointment updated successfully!";
        }
        
        // Send notification
        else if ($_POST['action'] === 'notify') {
            $id = $_POST['appointment_id'];
            
            // In a real application, you would send an SMS or email here
            // For now, we'll just update a notification_sent field
            $stmt = $conn->prepare("UPDATE appointments SET notification_sent = 1, updated_at = NOW() WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $stmt->close();
            
            $success_message = "Notification sent successfully!";
        }
    }
}

// Get appointments based on filter
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'pending';

$appointments = [];
$sql = "SELECT a.*, u.first_name, u.last_name, u.phone, u.email 
        FROM appointments a 
        LEFT JOIN users u ON a.user_id = u.id";

if ($status_filter !== 'all') {
    $sql .= " WHERE a.status = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $status_filter);
} else {
    $stmt = $conn->prepare($sql);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $appointments[] = $row;
    }
}

$stmt->close();
$conn->close();
?>

<div class="p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Appointments</h2>
        <div>
            <select class="form-select form-select-sm me-2 d-inline-block w-auto" id="filter-status">
                <option value="all" <?php echo $status_filter === 'all' ? 'selected' : ''; ?>>All Status</option>
                <option value="pending" <?php echo $status_filter === 'pending' ? 'selected' : ''; ?>>Pending</option>
                <option value="confirmed" <?php echo $status_filter === 'confirmed' ? 'selected' : ''; ?>>Confirmed</option>
                <option value="completed" <?php echo $status_filter === 'completed' ? 'selected' : ''; ?>>Completed</option>
                <option value="cancelled" <?php echo $status_filter === 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
            </select>
            <button class="btn btn-sm btn-outline-pink" id="refresh-btn">
                <i class="bi bi-arrow-clockwise me-1"></i> Refresh
            </button>
        </div>
    </div>

    <?php if (isset($success_message)): ?>
    <div class="alert alert-success" id="status-message"><?php echo $success_message; ?></div>
    <?php else: ?>
    <div class="alert alert-success d-none" id="status-message"></div>
    <?php endif; ?>

    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Time</th>
                    <th>Date</th>
                    <th>Service Type</th>
                    <th>Services</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="appointments-table">
                <?php if (count($appointments) > 0): ?>
                    <?php foreach ($appointments as $appointment): ?>
                        <tr>
                            <td>#<?php echo $appointment['id']; ?></td>
                            <td><?php echo $appointment['first_name'] . ' ' . $appointment['last_name']; ?></td>
                            <td><?php echo date('h:i A', strtotime($appointment['appointment_time'])); ?></td>
                            <td><?php echo date('m-d-Y', strtotime($appointment['appointment_date'])); ?></td>
                            <td><?php echo ucfirst($appointment['service_type']); ?></td>
                            <td><?php echo $appointment['services']; ?></td>
                            <td>
                                <span class="badge <?php 
                                    echo $appointment['status'] === 'confirmed' ? 'bg-primary' : 
                                        ($appointment['status'] === 'completed' ? 'bg-success' : 
                                        ($appointment['status'] === 'cancelled' ? 'bg-danger' : 'bg-secondary')); 
                                ?>">
                                    <?php echo ucfirst($appointment['status']); ?>
                                </span>
                            </td>
                            <td>
                                <button class="btn btn-sm btn-outline-secondary rounded-circle view-appointment" 
                                        data-appointment-id="<?php echo $appointment['id']; ?>">
                                    <i class="bi bi-eye"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="text-center">No appointments found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'components/modals/appointment_modal.php'; ?>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Sample appointment data for when database is empty
        let appointmentsData = <?php echo json_encode($appointments); ?>;
        
        if (appointmentsData.length === 0) {
            appointmentsData = [
                {
                    id: 1,
                    first_name: 'Jennie',
                    last_name: 'Kim',
                    phone: '+639123456789',
                    email: 'jennie@example.com',
                    appointment_date: '2023-02-15',
                    appointment_time: '10:27:00',
                    service_type: 'salon',
                    status: 'pending',
                    services: 'Hair Cut & Style, Hot Oil Treatment',
                    notes: 'First-time customer'
                },
                {
                    id: 2,
                    first_name: 'Customer',
                    last_name: '2',
                    phone: '+639123456782',
                    email: 'customer2@example.com',
                    appointment_date: '2023-02-15',
                    appointment_time: '12:18:00',
                    service_type: 'home',
                    status: 'pending',
                    services: 'Manicure & Pedicure',
                    notes: 'Address: Makati City'
                },
                {
                    id: 3,
                    first_name: 'Customer',
                    last_name: '3',
                    phone: '+639123456783',
                    email: 'customer3@example.com',
                    appointment_date: '2023-02-16',
                    appointment_time: '15:45:00',
                    service_type: 'salon',
                    status: 'confirmed',
                    services: 'Facial Treatment',
                    notes: ''
                }
            ];
        }

        // Filter change event
        document.getElementById('filter-status').addEventListener('change', function () {
            window.location.href = 'appointments.php?status=' + this.value;
        });

        // Refresh button
        document.getElementById('refresh-btn').addEventListener('click', function () {
            location.reload();
        });

        // Appointment modal
        const appointmentModal = new bootstrap.Modal(document.getElementById('appointmentModal'));

        // View appointment buttons
        document.querySelectorAll('.view-appointment').forEach(button => {
            button.addEventListener('click', function () {
                const appointmentId = this.getAttribute('data-appointment-id');
                openAppointmentModal(appointmentId);
            });
        });

        function openAppointmentModal(appointmentId) {
            // Find appointment data
            const appointment = appointmentsData.find(app => app.id == appointmentId);
            if (!appointment) return;

            // Format date for display
            const dateObj = new Date(appointment.appointment_date);
            const formattedDate = `${String(dateObj.getMonth() + 1).padStart(2, '0')}-${String(dateObj.getDate()).padStart(2, '0')}-${dateObj.getFullYear()}`;

            // Format time for display
            const timeObj = new Date(`2000-01-01T${appointment.appointment_time}`);
            const formattedTime = timeObj.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});

            // Populate modal
            document.getElementById('customer-name').textContent = appointment.first_name + ' ' + appointment.last_name;
            document.getElementById('customer-contact').textContent = `Phone: ${appointment.phone}`;
            document.getElementById('customer-email').textContent = `Email: ${appointment.email}`;
            document.getElementById('appointment-date').textContent = `Date: ${formattedDate}`;
            document.getElementById('appointment-time').textContent = `Time: ${formattedTime}`;
            document.getElementById('appointment-type').textContent = `Type: ${appointment.service_type === 'salon' ? 'Salon Service' : 'Home Service'}`;
            document.getElementById('appointment-notes').value = appointment.notes || '';
            document.getElementById('appointment-status').value = appointment.status;

            // Populate services
            const serviceList = document.getElementById('service-list');
            serviceList.innerHTML = '';
            
            if (appointment.services) {
                const services = appointment.services.split(',');
                services.forEach(service => {
                    const li = document.createElement('li');
                    li.innerHTML = `<i class="bi bi-circle-fill me-2 small"></i> ${service.trim()}`;
                    serviceList.appendChild(li);
                });
            }

            // Set data attribute for save button
            document.getElementById('save-appointment').setAttribute('data-appointment-id', appointmentId);
            document.getElementById('notify-customer').setAttribute('data-appointment-id', appointmentId);

            // Show modal
            appointmentModal.show();
        }

        // Save appointment changes
        document.getElementById('save-appointment').addEventListener('click', function () {
            const appointmentId = this.getAttribute('data-appointment-id');
            const status = document.getElementById('appointment-status').value;
            const notes = document.getElementById('appointment-notes').value;
            
            // Create form for submission
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const actionInput = document.createElement('input');
            actionInput.name = 'action';
            actionInput.value = 'update_status';
            form.appendChild(actionInput);
            
            const idInput = document.createElement('input');
            idInput.name = 'appointment_id';
            idInput.value = appointmentId;
            form.appendChild(idInput);
            
            const statusInput = document.createElement('input');
            statusInput.name = 'status';
            statusInput.value = status;
            form.appendChild(statusInput);
            
            const notesInput = document.createElement('input');
            notesInput.name = 'notes';
            notesInput.value = notes;
            form.appendChild(notesInput);
            
            document.body.appendChild(form);
            form.submit();
        });

        // Notify customer
        document.getElementById('notify-customer').addEventListener('click', function () {
            const appointmentId = this.getAttribute('data-appointment-id');
            
            // Create form for submission
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';
            
            const actionInput = document.createElement('input');
            actionInput.name = 'action';
            actionInput.value = 'notify';
            form.appendChild(actionInput);
            
            const idInput = document.createElement('input');
            idInput.name = 'appointment_id';
            idInput.value = appointmentId;
            form.appendChild(idInput);
            
            document.body.appendChild(form);
            form.submit();
        });

        // Show status message
        const statusMessage = document.getElementById('status-message');
        if (!statusMessage.classList.contains('d-none')) {
            // Hide after 3 seconds
            setTimeout(() => {
                statusMessage.classList.add('d-none');
            }, 3000);
        }
    });
</script>

<?php include 'components/footer.php'; ?>
