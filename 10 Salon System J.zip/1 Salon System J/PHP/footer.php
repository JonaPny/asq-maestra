<!-- footer.php -->
<footer>
    &copy; 2025 ASQ-Maestra Salon. All Rights Reserved.
  </footer>
  <script src="/JAVASCRIPT/homepage.js"></script>
  
</body>
</html>
