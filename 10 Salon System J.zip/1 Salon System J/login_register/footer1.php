<?php

?>
<footer class="footer">
  <div class="footer-container">
    <div class="footer-row">
      <div class="footer-col">
        <img class="footer-logo" src="/PHOTOS/logo.png" alt="Salon Logo">
        <p class="footer-about">Jose Maestra Barbera Salon is dedicated to enhancing our clients' beauty, hair, and confidence through exceptional services and outstanding performance</p>
      </div>
      
      <div class="footer-col">
        <h3 class="footer-heading">Contact Us</h3>
        <ul class="footer-contact">
          <li><i class="footer-icon location-icon"></i> Unit 6 Asia 1 Priscilla Commercial Hub Kapayapaan Road Canlubang, Calamba, Philippines</li>
          <li><i class="footer-icon phone-icon"></i> (555) 123-4567</li>
          <li><i class="footer-icon email-icon"></i> Josemaestrabarberasalon@gmail.com</li>
        </ul>
      </div>
      
      <div class="footer-col">
        <h3 class="footer-heading">Follow Us</h3>
        <div class="footer-social">
          <a href="https://www.facebook.com/share/18fx944W6r/" class="social-link facebook" aria-label="Facebook"><i class="social-icon facebook-icon"></i></a>
        </div>
      </div>
    </div>
    
    <div class="footer-bottom">
      <small class="footer-copyright">&copy; <?php echo date('Y'); ?> ASQ-Maestra Salon. All Rights Reserved.</small>
    </div>
  </div>
  
  <style>
   
    /* Footer Styles */
    .footer {
      background-color: #333;
      padding: 3rem 0 1.5rem;
      color: #fff;
    }
    
    .footer-container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 1rem;
    }
    
    .footer-row {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      margin-bottom: 2rem;
    }
    
    .footer-col {
      flex: 1;
      min-width: 250px;
      margin-bottom: 1.5rem;
      padding-right: 2rem;
    }
    
    .footer-logo {
      width: 60px;
      height: auto;
      margin-bottom: 1rem;
    }
    
    .footer-about {
      font-size: 0.9rem;
      line-height: 1.6;
      color: #ccc;
    }
    
    .footer-heading {
      font-size: 1.2rem;
      margin-bottom: 1.2rem;
      position: relative;
      padding-bottom: 0.5rem;
    }
    
    .footer-heading:after {
      content: '';
      position: absolute;
      left: 0;
      bottom: 0;
      width: 50px;
      height: 2px;
      background-color:rgb(233, 19, 108) /* Salon-themed accent color */
    }
    
    .footer-contact {
      list-style: none;
      padding: 0;
      margin: 0;
    }
    
    .footer-contact li {
      margin-bottom: 0.8rem;
      display: flex;
      align-items: center;
      font-size: 0.9rem;
      color: #ccc;
    }
    
    .footer-icon {
      margin-right: 0.5rem;
      width: 16px;
      height: 16px;
      display: inline-block;
    }
    
    /* Simple icon placeholders - replace with actual icons */
    .location-icon:before { content: "📍"; }
    .phone-icon:before { content: "📞"; }
    .email-icon:before { content: "✉️"; }
    
    .footer-social {
      display: flex;
      gap: 1rem;
    }
    
    .social-link {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background-color: rgba(255, 255, 255, 0.1);
      transition: all 0.3s ease;
    }
    
    .social-link:hover {
      background-color:rgb(233, 19, 108);
      transform: translateY(-3px);
    }
    
    /* Simple icon placeholders - replace with actual icons */
    .facebook-icon:before { content: "f"; color: white; font-weight: bold; }
    .instagram-icon:before { content: "ig"; color: white; font-weight: bold; }
    .twitter-icon:before { content: "t"; color: white; font-weight: bold; }
    .pinterest-icon:before { content: "p"; color: white; font-weight: bold; }
    
    .footer-bottom {
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      padding-top: 1.5rem;
      text-align: center;
    }
    
    .footer-copyright {
      color: #999;
      font-size: 0.875rem;
    }
    
    /* Responsive adjustments */
    @media (max-width: 768px) {
      .footer-row {
        flex-direction: column;
      }
      
      .footer-col {
        padding-right: 0;
      }
    }
  </style>
</footer>