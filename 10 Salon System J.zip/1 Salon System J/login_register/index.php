<?php include('header1.php'); ?>
<?php include('services-data.php'); ?>

<link rel="stylesheet" href="/CSS/homepage.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Poppins:wght@300;400;500;600&display=swap"/>
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

<div class="hero-section">
  <!-- Overlay -->
  <div class="hero-overlay"></div>

  <!-- Content -->
  <div class="hero-container">
    <div class="hero-content">
      <h1 class="hero-title">
        <strong>INDULGE IN BEAUTY, RELAX IN LUXURY.</strong>
      </h1>
      <p class="hero-subtitle">
        We Are Your Destination for <br>
        Beauty & Confidence
      </p>
      <a href="/login_register/login.php" class="hero-btn">
        SET AN APPOINTMENT NOW!
      </a>
    </div>
  </div>
</div>

<section class="services-section">
  <div class="container">
    <div class="section-header">
      <h2 class="section-title">Our Services</h2>
      <div class="title-underline"></div>
      <p class="section-description">
        Discover our comprehensive range of beauty services tailored to enhance your natural beauty and boost your confidence.
      </p>
    </div>

    <?php
    // Get services from database
    $servicesGrouped = getServicesGroupedByCategory();
    
    // If no services found, show a message
    if (empty($servicesGrouped)) {
        echo '<div class="alert alert-info">No services available at the moment. Please check back later.</div>';
    } else {
    ?>

    <!-- Category Navigation -->
    <div class="category-nav">
      <?php
      // Get all category IDs
      $categoryIds = array_keys($servicesGrouped);
      
      // Loop through categories to create navigation buttons
      foreach ($categoryIds as $index => $categoryId) {
          $isActive = ($index === 0) ? 'active' : '';
          $icon = getCategoryIcon($categoryId);
          $displayName = getCategoryDisplayName($categoryId);
          
          echo '<button class="category-btn ' . $isActive . '" data-category="' . $categoryId . '">';
          echo '<i class="' . $icon . '"></i> ' . $displayName;
          echo '</button>';
      }
      ?>
    </div>

    <!-- Services Display -->
    <div class="services-container">
      <?php
      // Loop through categories to create service sections
      foreach ($servicesGrouped as $categoryId => $services) {
          $isActive = ($categoryId === $categoryIds[0]) ? 'active' : '';
          
          echo '<div class="service-category ' . $isActive . '" id="' . $categoryId . '">';
          echo '<div class="services-grid">';
          
          // Loop through services in this category
          foreach ($services as $service) {
              ?>
              <div class="service-card">
                <div class="service-content">
                  <?php if (!empty($service['image_path'])): ?>
                  <div class="service-image">
                    <img src="<?php echo $service['image_path']; ?>" alt="<?php echo htmlspecialchars($service['name']); ?>">
                  </div>
                  <?php endif; ?>
                  <div class="service-header">
                    <h3 class="service-title"><?php echo htmlspecialchars($service['name']); ?></h3>
                    <span class="service-price">₱<?php echo number_format($service['price'], 0); ?></span>
                  </div>
                  <p class="service-description"><?php echo htmlspecialchars($service['description']); ?></p>
                  <div class="service-footer">
                    <span class="service-duration">Duration: <?php echo $service['duration']; ?> mins</span>
                    <button class="book-btn" data-service-id="<?php echo $service['id']; ?>">Book Now</button>
                  </div>
                </div>
              </div>
              <?php
          }
          
          echo '</div>'; // Close services-grid
          echo '</div>'; // Close service-category
      }
      ?>
    </div>
    <?php } // End if services exist ?>
  </div>
</section>

<?php include('footer1.php'); ?>

<script src="/JAVASCRIPT/services.js"></script>