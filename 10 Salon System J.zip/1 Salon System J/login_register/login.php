<?php 
date_default_timezone_set('Asia/Manila');
include('header1.php');

// Include the consolidated database connection
include "tools/salondb.php";
$dbConnection = getDatabaseConnection();

// Remove the old admin database connection include
// The line below was causing the error:
// require_once __DIR__ . '/../admin/includes/db_connection.php';

$email = $_GET['email'] ?? ''; // Autofill if redirected
$password = "";
$email_error = $password_error = "";
$error = false;

// For admin login
$admin_username = "";
$admin_password = "";
$admin_username_error = $admin_password_error = "";
$admin_error = false;

// Regular user login processing
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['user_login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $email_error = "Invalid email format";
        $error = true;
    }

    if (empty($password)) {
        $password_error = "Password is required";
        $error = true;
    }

    if (!$error) {
        // Add 'name' to the SELECT query
        $statement = $dbConnection->prepare("SELECT id, first_name, last_name, password FROM users WHERE email = ?");
        $statement->bind_param("s", $email);
        $statement->execute();
        $statement->store_result();

        if ($statement->num_rows == 1) {
            $statement->bind_result($user_id, $first_name, $last_name, $hashed_password);
            $statement->fetch();

            if (password_verify($password, $hashed_password)) {
                // Set session variables including the user's name
                $_SESSION['email'] = $email;
                $_SESSION['user_id'] = $user_id;
                $_SESSION['name'] = $first_name . ' ' . $last_name; // Store the user's name in the session
                
                // Redirect to customer page
                header("Location: ../user/customer.php");
                exit;
            } else {
                $password_error = "Incorrect password";
            }
        } else {
            $email_error = "Email not found";
        }

        $statement->close();
    }
}

// Admin login processing
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['admin_login'])) {
    $admin_username = $_POST['admin_username'];
    $admin_password = $_POST['admin_password'];
    
    if (empty($admin_username)) {
        $admin_username_error = "Username is required";
        $admin_error = true;
    }
    
    if (empty($admin_password)) {
        $admin_password_error = "Password is required";
        $admin_error = true;
    }
    
    if (!$admin_error) {
        // Use the getAdminDatabaseConnection function from the consolidated file
        $conn = getAdminDatabaseConnection();
        
        // Check admin credentials in database
        $stmt = $conn->prepare("SELECT admin_id, username, password FROM admin_users WHERE username = ?");
        $stmt->bind_param("s", $admin_username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows == 1) {
            $admin = $result->fetch_assoc();
            
            // Verify password (using password_verify if passwords are hashed)
            if (password_verify($admin_password, $admin['password']) || $admin_password === $admin['password']) { // Second condition for non-hashed passwords during development
                $_SESSION['admin_logged_in'] = true;
                $_SESSION['admin_username'] = $admin_username;
                $_SESSION['admin_id'] = $admin['admin_id'];
                
                // Redirect to admin dashboard
                header("Location: ../admin/dashboard.php");
                exit;
            } else {
                $admin_password_error = "Invalid username or password";
            }
        } else {
            $admin_username_error = "Invalid username or password";
        }
        
        $stmt->close();
        $conn->close();
    }
}
?>

<link rel="stylesheet" href="/CSS/login.css">

<!-- Login Form -->
<div class="container">
    <div class="form-container">
        <h2 class="form-title">Customer Login</h2>
        <hr />

        <form method="post">
            <div class="form-row">
                <label class="form-label">Email</label>
                <div class="form-input-container">
                    <input class="form-input" name="email" type="email" value="<?= htmlspecialchars($email); ?>">
                    <span class="error-text"><?= $email_error ?></span>
                </div>
            </div>
            
            <div class="form-row">
                <label class="form-label">Password</label>
                <div class="form-input-container">
                    <input class="form-input" name="password" type="password">
                    <span class="error-text"><?= $password_error ?></span>
                </div>
            </div>
            
            <div class="form-row button-row">
                <button type="submit" name="user_login" class="submit-btn">Login</button>
                <a href="/login_register/index.php" class="cancel-btn">Cancel</a>
            </div>
        </form>

        <p class="register-link">Don't have an account? <a href="register.php">Register here</a></p>
    </div>

    <div class="form-container">
        <h2 class="form-title">Admin Login</h2>
        <hr />

        <form method="post">
            <div class="form-row">
                <label class="form-label">Username</label>
                <div class="form-input-container">
                    <input class="form-input" name="admin_username" type="text" value="<?= htmlspecialchars($admin_username); ?>">
                    <span class="error-text"><?= $admin_username_error ?></span>
                </div>
            </div>
            
            <div class="form-row">
                <label class="form-label">Password</label>
                <div class="form-input-container">
                    <input class="form-input" name="admin_password" type="password">
                    <span class="error-text"><?= $admin_password_error ?></span>
                </div>
            </div>
            
            <div class="form-row button-row">
                <button type="submit" name="admin_login" class="submit-btn">Login</button>
                <a href="/login_register/index.php" class="cancel-btn">Cancel</a>
            </div>
        </form>
    </div>
</div>

<?php include('footer1.php'); ?>
