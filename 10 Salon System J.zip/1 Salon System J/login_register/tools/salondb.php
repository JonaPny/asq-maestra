<?php
function getDatabaseConnection() {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "login_register_salondb";

    // Check if we should return a mysqli or PDO connection
    $connectionType = func_num_args() > 0 ? func_get_arg(0) : 'mysqli';
    
    if ($connectionType === 'pdo') {
        try {
            $pdo = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $pdo;
        } catch (PDOException $e) {
            die("Error failed to connect to MySQL: " . $e->getMessage());
        }
    } else {
        // Default to mysqli
        $connection = new mysqli($servername, $username, $password, $database);
        if($connection->connect_error) {
            die("Error failed to connect to MySQL: " . $connection->connect_error);
        }
        return $connection;
    }
}

// For backward compatibility
function getAdminDatabaseConnection() {
    return getDatabaseConnection();
}
?>
