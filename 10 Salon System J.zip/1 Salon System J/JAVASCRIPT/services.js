document.addEventListener("DOMContentLoaded", () => {
  // Category Navigation
  const categoryButtons = document.querySelectorAll(".category-btn")
  const serviceCategories = document.querySelectorAll(".service-category")

  // Set initial active category
  document.querySelector(".category-btn").classList.add("active")
  document.querySelector(".service-category").classList.add("active")

  // Add click event listeners to category buttons
  categoryButtons.forEach((button) => {
    button.addEventListener("click", function () {
      // Remove active class from all buttons
      categoryButtons.forEach((btn) => btn.classList.remove("active"))

      // Add active class to clicked button
      this.classList.add("active")

      // Get the category ID
      const categoryId = this.getAttribute("data-category")

      // Hide all service categories
      serviceCategories.forEach((category) => {
        category.classList.remove("active")
      })

      // Show the selected category
      document.getElementById(categoryId).classList.add("active")

      // Animate service cards
      animateServiceCards(categoryId)
    })
  })

  // Animate service cards with delay
  function animateServiceCards(categoryId) {
    const cards = document.querySelectorAll(`#${categoryId} .service-card`)

    cards.forEach((card, index) => {
      // Reset animation
      card.style.animation = "none"
      card.offsetHeight // Trigger reflow

      // Apply animation with delay based on index
      card.style.animation = `cardAppear 0.5s ease forwards ${index * 0.1}s`
    })
  }

  // Initialize first category animation
  animateServiceCards("haircut")

const bookButtons = document.querySelectorAll(".book-btn, .package-btn");

bookButtons.forEach((button) => {
  button.addEventListener("click", () => {
    // Create a confirmation message
    const message = confirm("You need to create an account or log in to proceed with booking. Would you like to continue?");
    
    // If user confirms, redirect to the login page
    if (message) {
      window.location.href = "login.php";
    }
  });
});


  // Add hover effects to service cards
  const serviceCards = document.querySelectorAll(".service-card")

  serviceCards.forEach((card) => {
    card.addEventListener("mouseenter", function () {
      this.style.backgroundColor = "#fff9fc"
    })

    card.addEventListener("mouseleave", function () {
      this.style.backgroundColor = "#fff"
    })
  })

  // Add scroll reveal animation
  const revealElements = document.querySelectorAll(".promo-banner, .packages-section")

  function checkScroll() {
    revealElements.forEach((element) => {
      const elementTop = element.getBoundingClientRect().top
      const windowHeight = window.innerHeight

      if (elementTop < windowHeight - 100) {
        element.style.opacity = "1"
        element.style.transform = "translateY(0)"
      }
    })
  }

  // Set initial styles for reveal elements
  revealElements.forEach((element) => {
    element.style.opacity = "0"
    element.style.transform = "translateY(20px)"
    element.style.transition = "opacity 0.5s ease, transform 0.5s ease"
  })

  // Check on scroll
  window.addEventListener("scroll", checkScroll)

  // Check on initial load
  checkScroll()
})
