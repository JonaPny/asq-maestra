document.addEventListener("DOMContentLoaded", () => {
    // Category tab switching
    const categoryTabs = document.querySelectorAll(".category-tab")
    const categoryContents = document.querySelectorAll(".category-content")
  
    categoryTabs.forEach((tab) => {
      tab.addEventListener("click", function () {
        // Remove active class from all tabs and contents
        categoryTabs.forEach((t) => t.classList.remove("active"))
        categoryContents.forEach((c) => c.classList.remove("active"))
  
        // Add active class to clicked tab
        this.classList.add("active")
  
        // Show corresponding content
        const category = this.getAttribute("data-category")
        const content = document.getElementById(category + "-content")
        if (content) {
          content.classList.add("active")
        }
      })
    })
  
    // Add to cart functionality
    const addToCartButtons = document.querySelectorAll(".add-to-cart-btn")
  
    addToCartButtons.forEach((button) => {
      button.addEventListener("click", function () {
        const serviceCard = this.closest(".service-card")
        const serviceId = serviceCard.getAttribute("data-id")
        const serviceName = serviceCard.getAttribute("data-name")
        const servicePrice = serviceCard.getAttribute("data-price")
  
        // Add to cart logic
        addToCart(serviceId, serviceName, servicePrice)
      })
    })
  
    function addToCart(id, name, price) {
      // Create a custom event to communicate with the cart component
      const event = new CustomEvent("addToCart", {
        detail: {
          id: id,
          name: name,
          price: price,
          quantity: 1,
        },
      })
  
      // Dispatch the event
      document.dispatchEvent(event)
  
      // Show notification
      alert(`Added ${name} to cart!`)
    }
  })
  