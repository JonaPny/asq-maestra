<div class="page" id="history-page">
    <h2>Booking History</h2>
    <div class="tabs">
        <button class="tab active" data-tab="upcoming">Upcoming</button>
        <button class="tab" data-tab="past">Past Appointments</button>
    </div>

    <div class="tab-content active" id="upcoming-content">
        <div class="appointment-card">
            <div class="appointment-date">
                <div class="month">May</div>
                <div class="day">10</div>
                <div class="year">2025</div>
            </div>
            <div class="appointment-details">
                <h3>Brazilian Keratin Straight Treatment</h3>
                <p><i class="fas fa-clock"></i> 2:00 PM - 4:00 PM</p>
                <p><i class="fas fa-user"></i> Stylist: Myrsel Jose</p>
                <div class="appointment-status confirmed">Confirmed</div>
            </div>
            <div class="appointment-actions">
                <button class="reschedule-btn">Reschedule</button>
                <button class="cancel-btn">Cancel</button>
            </div>
        </div>

        <div class="appointment-card">
            <div class="appointment-date">
                <div class="month">May</div>
                <div class="day">24</div>
                <div class="year">2025</div>
            </div>
            <div class="appointment-details">
                <h3>Full Highlights</h3>
                <p><i class="fas fa-clock"></i> 10:00 AM - 11:00 AM</p>
                <p><i class="fas fa-user"></i> Stylist: Boss Uno</p>
                <div class="appointment-status pending">Pending</div>
            </div>
            <div class="appointment-actions">
                <button class="reschedule-btn">Reschedule</button>
                <button class="cancel-btn">Cancel</button>
            </div>
        </div>
    </div>

    <div class="tab-content" id="past-content">
        <div class="appointment-card past">
            <div class="appointment-date">
                <div class="month">Apr</div>
                <div class="day">15</div>
                <div class="year">2025</div>
            </div>
            <div class="appointment-details">
                <h3>FHP #1</h3>
                <p><i class="fas fa-clock"></i> 3:30 PM - 4:30 PM</p>
                <p><i class="fas fa-user"></i> Stylist: Myrsel Jose</p>
                <div class="appointment-status completed">Completed</div>
            </div>
            <div class="appointment-actions">
                <button class="review-btn">Leave Review</button>
                <button class="rebook-btn">Book Again</button>
            </div>
        </div>

        <div class="appointment-card past">
            <div class="appointment-date">
                <div class="month">Mar</div>
                <div class="day">22</div>
                <div class="year">2025</div>
            </div>
            <div class="appointment-details">
                <h3>Haircut Women</h3>
                <p><i class="fas fa-clock"></i> 1:00 PM - 3:30 PM</p>
                <p><i class="fas fa-user"></i> Stylist: Boss Uno</p>
                <div class="appointment-status completed">Completed</div>
            </div>
            <div class="appointment-actions">
                <button class="review-btn">Leave Review</button>
                <button class="rebook-btn">Book Again</button>
            </div>
        </div>
    </div>
</div>
