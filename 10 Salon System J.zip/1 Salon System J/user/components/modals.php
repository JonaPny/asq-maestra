<!-- Checkout Modal -->
<div class="modal" id="checkout-modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Checkout</h2>
            <button class="close-modal">&times;</button>
        </div>
        <div class="modal-body">
            <form id="checkout-form" method="post">
                <input type="hidden" name="action" value="create_appointment">
                
                <div class="checkout-section">
                    <h3>Selected Services</h3>
                    <div id="checkout-items">
                        <!-- Services will be added here dynamically -->
                    </div>
                    <div class="checkout-summary">
                        <div class="summary-row">
                            <span>Subtotal:</span>
                            <span id="checkout-subtotal">₱0.00</span>
                        </div>
                        <div id="checkout-transportation-container" class="summary-row" style="display: none;">
                            <span>Transportation Fee:</span>
                            <span id="checkout-transportation">₱0.00</span>
                        </div>
                        <div class="summary-row total">
                            <span>Total:</span>
                            <span id="checkout-total">₱0.00</span>
                        </div>
                        <div id="checkout-deposit-info" class="hidden">
                            <div class="summary-row">
                                <span>Deposit Amount (50%):</span>
                                <span id="checkout-deposit">₱0.00</span>
                            </div>
                            <div class="summary-row">
                                <span>Balance Due at Appointment:</span>
                                <span id="checkout-balance">₱0.00</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="checkout-section">
                    <h3>Appointment Details</h3>
                    <div class="form-group">
                        <label for="appointment-date">Date:</label>
                        <input type="date" id="appointment-date" name="appointment_date" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="appointment-time">Time:</label>
                        <select id="appointment-time" name="appointment_time" class="form-control" required>
                            <option value="">Select a date first</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="checkout-service-type">Service Type:</label>
                        <select id="checkout-service-type" name="service_type" class="form-control" required>
                            <option value="salon">Salon Service</option>
                            <option value="home">Home Service</option>
                        </select>
                    </div>
                    
                    <div id="checkout-location-container">
                        <div id="checkout-location-details" style="display: none;">
                            <div class="form-group">
                                <label for="checkout-location-area">Location Area:</label>
                                <select id="checkout-location-area" name="location_area" class="form-control">
                                    <option value="canlubang">Within Canlubang</option>
                                    <option value="calamba">Within Calamba (outside Canlubang)</option>
                                    <option value="outside">Outside Calamba</option>
                                </select>
                            </div>
                            <div id="checkout-custom-fee-container" style="display: none;">
                                <div class="form-group">
                                    <label for="checkout-custom-fee">Custom Transportation Fee (₱):</label>
                                    <input type="number" id="checkout-custom-fee" name="transportation_fee" class="form-control" min="1000" step="100" value="1000">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="checkout-address">Complete Address:</label>
                                <textarea id="checkout-address" name="address" class="form-control" rows="3" placeholder="Enter your complete address for home service"></textarea>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="checkout-notes">Special Instructions:</label>
                        <textarea id="checkout-notes" name="notes" class="form-control" rows="3" placeholder="Any special requests or instructions"></textarea>
                    </div>
                </div>
                
                <div class="checkout-section">
                    <h3>Payment Method</h3>
                    <input type="hidden" id="payment-method" name="payment_method" value="cash">
                    <input type="hidden" id="payment-status" name="payment_status" value="full">
                    <div class="payment-cards">
                        <div class="payment-card selected" data-method="cash">
                            <i class="fas fa-money-bill-wave"></i>
                            <span>Cash</span>
                        </div>
                        <div class="payment-card" data-method="credit">
                            <i class="fas fa-credit-card"></i>
                            <span>Credit Card</span>
                        </div>
                        <div class="payment-card" data-method="gcash">
                            <i class="fas fa-mobile-alt"></i>
                            <span>GCash</span>
                        </div>
                        <div class="payment-card" data-method="maya">
                            <i class="fas fa-wallet"></i>
                            <span>Maya</span>
                        </div>
                    </div>
                    
                    <div id="payment-forms">
                        <div id="credit-card-form" class="payment-form" style="display: none;">
                            <div class="form-group">
                                <label for="card-number">Card Number:</label>
                                <input type="text" id="card-number" class="form-control" placeholder="1234 5678 9012 3456">
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="card-expiry">Expiry Date:</label>
                                    <input type="text" id="card-expiry" class="form-control" placeholder="MM/YY">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="card-cvv">CVV:</label>
                                    <input type="text" id="card-cvv" class="form-control" placeholder="123">
                                </div>
                            </div>
                        </div>
                        
                        <div id="gcash-form" class="payment-form" style="display: none;">
                            <div class="form-group">
                                <label for="gcash-number">GCash Number:</label>
                                <input type="text" id="gcash-number" class="form-control" placeholder="09XX XXX XXXX">
                            </div>
                        </div>
                        
                        <div id="maya-form" class="payment-form" style="display: none;">
                            <div class="form-group">
                                <label for="maya-number">Maya Account Number:</label>
                                <input type="text" id="maya-number" class="form-control" placeholder="09XX XXX XXXX">
                            </div>
                        </div>
                    </div>
                </div>
                
                <input type="hidden" id="services-json" name="services_json">
                <input type="hidden" id="subtotal-amount" name="subtotal">
                <input type="hidden" id="transportation-amount" name="transportation_fee">
                <input type="hidden" id="total-amount" name="total">
            </form>
        </div>
        <div class="modal-footer">
            <button class="close-modal">Cancel</button>
            <button id="confirm-booking" class="primary-btn">Confirm Booking</button>
        </div>
    </div>
</div>

<!-- Confirmation Modal -->
<div class="modal" id="confirmation-modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Booking Confirmed!</h2>
            <button id="close-confirmation">&times;</button>
        </div>
        <div class="modal-body">
            <div class="confirmation-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <h3>Thank you for your booking!</h3>
            <p>Your appointment has been scheduled. We'll send you a confirmation shortly.</p>
            
            <div class="confirmation-details">
                <div class="detail-row">
                    <span class="detail-label">Date:</span>
                    <span id="confirmed-date" class="detail-value">January 1, 2023</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Time:</span>
                    <span id="confirmed-time" class="detail-value">10:00 AM</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Services:</span>
                    <span id="confirmed-services" class="detail-value">Haircut, Manicure</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Service Type:</span>
                    <span id="confirmed-service-type" class="detail-value">Salon Service</span>
                </div>
                <div id="confirmed-location-container" style="display: none;">
                    <div class="detail-row">
                        <span class="detail-label">Location Area:</span>
                        <span id="confirmed-location" class="detail-value">Within Canlubang</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Address:</span>
                        <span id="confirmed-address" class="detail-value">123 Main St, Canlubang</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Transportation Fee:</span>
                        <span id="confirmed-transportation" class="detail-value">₱0.00</span>
                    </div>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Total:</span>
                    <span id="confirmed-total" class="detail-value">₱1,500.00</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Payment Method:</span>
                    <span id="confirmed-payment-method" class="detail-value">Cash</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Payment Status:</span>
                    <span id="confirmed-payment" class="detail-value">Paid in Full</span>
                </div>
            </div>
            
            <div class="confirmation-note">
                <p>A confirmation has been sent to your email. If you need to make any changes to your appointment, please contact us.</p>
            </div>
        </div>
        <div class="modal-footer">
            <button id="close-confirmation-btn" class="primary-btn">Done</button>
        </div>
    </div>
</div>
