<!-- Cart Sidebar -->
<div class="cart-sidebar" id="cart-sidebar">
    <div class="cart-header">
        <h2>Your Cart</h2>
        <button id="close-cart"><i class="fas fa-times"></i></button>
    </div>
    <div class="cart-scrollable-content">
        <div class="cart-items" id="cart-items">
            <!-- Cart items will be added here dynamically -->
            <div class="empty-cart-message">Your cart is empty</div>
        </div>
        <div class="cart-summary">
            <div class="summary-row">
                <span>Subtotal:</span>
                <span id="cart-subtotal">₱0.00</span>
            </div>
            <div id="transportation-fee-container" class="summary-row" style="display: none;">
                <span>Transportation Fee:</span>
                <span id="transportation-fee">₱0.00</span>
            </div>
            <div class="summary-row total">
                <span>Total:</span>
                <span id="cart-total">₱0.00</span>
            </div>
        </div>
        
        <div id="service-location-container" style="display: none;">
            <h3>Service Location</h3>
            <div class="form-group">
                <label for="service-type">Service Type:</label>
                <select id="service-type" class="form-control">
                    <option value="salon">Salon Service</option>
                    <option value="home">Home Service</option>
                </select>
            </div>
            
            <div id="location-details" style="display: none;">
                <div class="form-group">
                    <label for="location-area">Location Area:</label>
                    <select id="location-area" class="form-control">
                        <option value="canlubang">Within Canlubang</option>
                        <option value="calamba">Within Calamba (outside Canlubang)</option>
                        <option value="outside">Outside Calamba</option>
                    </select>
                </div>
                <div id="custom-fee-container" style="display: none;">
                    <div class="form-group">
                        <label for="custom-fee">Custom Transportation Fee (₱):</label>
                        <input type="number" id="custom-fee" class="form-control" min="1000" step="100" value="1000">
                    </div>
                </div>
                <div class="location-note">
                    <p><strong>Note:</strong> Transportation fees apply for home services:</p>
                    <ul>
                        <li>Within Canlubang: No fee</li>
                        <li>Within Calamba: ₱500</li>
                        <li>Outside Calamba: ₱1,000 or more</li>
                    </ul>
                </div>
            </div>
        </div>
        
        <div class="payment-options">
            <h3>Payment Options</h3>
            <div class="payment-option">
                <input type="radio" id="full-payment" name="payment-option" value="full" checked>
                <label for="full-payment">Pay in Full</label>
            </div>
            <div class="payment-option">
                <input type="radio" id="deposit-payment" name="payment-option" value="deposit">
                <label for="deposit-payment">50% Deposit</label>
                <div class="deposit-info" id="deposit-info">
                    <div class="summary-row">
                        <span>Deposit Amount (50%):</span>
                        <span id="deposit-amount">₱0.00</span>
                    </div>
                    <div class="summary-row">
                        <span>Balance Due at Appointment:</span>
                        <span id="balance-due">₱0.00</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <button class="checkout-btn" id="checkout-btn">Proceed to Checkout</button>
</div>

<!-- Overlay -->
<div class="overlay" id="overlay"></div>
