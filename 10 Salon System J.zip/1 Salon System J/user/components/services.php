<?php
// Fix the include path issue by using a more reliable path resolution
$rootPath = $_SERVER['DOCUMENT_ROOT'];
$projectPath = dirname(dirname(dirname(__FILE__))); // Go up two levels from components

// Try multiple possible paths to find the database connection file
$possiblePaths = [
    // Absolute path using document root
    $rootPath . '/login_register/tools/salondb.php',
    // Path relative to project root
    $projectPath . '/login_register/tools/salondb.php',
    // Original relative path
    '../login_register/tools/salondb.php',
    // Alternative relative path
    '../../login_register/tools/salondb.php',
    // Direct path for VS Code PHP Server
    __DIR__ . '/../../login_register/tools/salondb.php'
];

$dbFileFound = false;
foreach ($possiblePaths as $path) {
    if (file_exists($path)) {
        include_once $path;
        $dbFileFound = true;
        break;
    }
}

// If we couldn't find the file, define a fallback function
if (!$dbFileFound || !function_exists('getDatabaseConnection')) {
    function getDatabaseConnection() {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "login_register_salondb";

        // Check if we should return a mysqli or PDO connection
        $connectionType = func_num_args() > 0 ? func_get_arg(0) : 'mysqli';
        
        if ($connectionType === 'pdo') {
            try {
                $pdo = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                return $pdo;
            } catch (PDOException $e) {
                die("Error failed to connect to MySQL: " . $e->getMessage());
            }
        } else {
            // Default to mysqli
            $connection = new mysqli($servername, $username, $password, $database);
            if($connection->connect_error) {
                die("Error failed to connect to MySQL: " . $connection->connect_error);
            }
            return $connection;
        }
    }
}

$conn = getDatabaseConnection();

// Replace the existing category ordering code with this improved version that ensures the correct order

// Define the order of categories to match admin interface with proper capitalization
$categoryOrder = [
    'All',
    'Haircuts',
    'Hair Color',
    'Rebonding',
    'Hair Treatment',
    'Braiding',
    'Nails',
    'For Men',
    'For Women'
];

// Map database categories to display names with proper capitalization
$categoryDisplayNames = [
    'all' => 'All',
    'haircuts' => 'Haircuts',
    'haircolor' => 'Hair Color',
    'rebonding' => 'Rebonding',
    'treatment' => 'Hair Treatment',
    'braiding' => 'Braiding',
    'nails' => 'Nails',
    'men' => 'For Men',
    'women' => 'For Women'
];

// Get all active categories
$categories = [];
$categoryQuery = "SELECT DISTINCT category FROM services WHERE status = 1";
$categoryResult = $conn->query($categoryQuery);
if ($categoryResult && $categoryResult->num_rows > 0) {
    $dbCategories = [];
    while ($row = $categoryResult->fetch_assoc()) {
        $dbCategories[] = $row['category'];
    }
    
    // First add categories in the predefined order if they exist in the database
    foreach ($categoryOrder as $orderedCategory) {
        // Convert to lowercase for comparison with database values
        $lowerCategory = strtolower($orderedCategory);
        $lowerCategory = str_replace(' ', '', $lowerCategory); // Remove spaces for comparison
        
        foreach ($dbCategories as $dbCategory) {
            $lowerDbCategory = strtolower($dbCategory);
            $lowerDbCategory = str_replace(' ', '', $lowerDbCategory);
            
            if ($lowerDbCategory === $lowerCategory) {
                // Use the properly capitalized version from our predefined list
                $categories[] = [
                    'db_value' => $dbCategory, // Original value from DB for filtering
                    'display_name' => $orderedCategory // Properly capitalized display name
                ];
                break;
            }
        }
    }
    
    // Then add any remaining categories from the database that weren't in our predefined order
    foreach ($dbCategories as $dbCategory) {
        $found = false;
        foreach ($categories as $category) {
            if ($category['db_value'] === $dbCategory) {
                $found = true;
                break;
            }
        }
        
        if (!$found) {
            // Try to find a display name in our map, otherwise use the DB value
            $lowerDbCategory = strtolower($dbCategory);
            $lowerDbCategory = str_replace(' ', '', $lowerDbCategory);
            
            $displayName = $dbCategory; // Default to DB value
            foreach ($categoryDisplayNames as $key => $value) {
                if (strtolower(str_replace(' ', '', $key)) === $lowerDbCategory) {
                    $displayName = $value;
                    break;
                }
            }
            
            $categories[] = [
                'db_value' => $dbCategory,
                'display_name' => $displayName
            ];
        }
    }
} else {
    // Fallback to predefined categories if none found in database
    foreach ($categoryOrder as $category) {
        $categories[] = [
            'db_value' => strtolower(str_replace(' ', '', $category)),
            'display_name' => $category
        ];
    }
}

// Get all active services
$services = [];
$servicesQuery = "SELECT * FROM services WHERE status = 1 ORDER BY category, name";
$servicesResult = $conn->query($servicesQuery);
if ($servicesResult && $servicesResult->num_rows > 0) {
    while ($row = $servicesResult->fetch_assoc()) {
        $services[] = $row;
    }
}

// Special handling for "All" category
$hasAll = false;
foreach ($categories as $category) {
    if ($category['display_name'] === 'All') {
        $hasAll = true;
        break;
    }
}

if (!$hasAll && count($categories) > 0) {
    array_unshift($categories, [
        'db_value' => 'all',
        'display_name' => 'All'
    ]);
}
?>

<!-- Include the external CSS file -->
<link rel="stylesheet" href="/user/assets/css/services.css">


<div class="page active" id="services-page">
    <h2>Our Services</h2>
    <div class="categories">
        <div class="category-tabs">
            <!-- Hardcoded tabs in the exact order we want -->
            <button class="category-tab active" data-category="all">All</button>
            <button class="category-tab" data-category="haircuts">Haircuts</button>
            <button class="category-tab" data-category="hair-color">Hair Color</button>
            <button class="category-tab" data-category="rebonding">Rebonding</button>
            <button class="category-tab" data-category="hair-treatment">Hair Treatment</button>
            <button class="category-tab" data-category="braiding">Braiding</button>
            <button class="category-tab" data-category="nails">Nails</button>
            <button class="category-tab" data-category="for-men">For Men</button>
            <button class="category-tab" data-category="for-women">For Women</button>
        </div>

        <?php if (count($categories) > 0): ?>
            <?php foreach ($categories as $index => $category): ?>
                <?php 
                $categoryId = strtolower(str_replace(' ', '-', $category['display_name']));
                $isAllCategory = ($category['display_name'] === 'All');
                ?>
                <div class="category-content <?php echo $index === 0 ? 'active' : ''; ?>" 
                     id="<?php echo htmlspecialchars($categoryId); ?>-content">
                    <div class="subcategory-grid">
                        <?php 
                        // Filter services based on category
                        $categoryServices = [];
                        if ($isAllCategory) {
                            $categoryServices = $services; // All services
                        } else {
                            $categoryServices = array_filter($services, function($service) use ($category) {
                                // Case-insensitive comparison for category matching
                                return strcasecmp($service['category'], $category['db_value']) === 0;
                            });
                        }
                        
                        if (count($categoryServices) > 0):
                            foreach ($categoryServices as $service):
                        ?>
                            <div class="service-card" 
                                data-id="<?php echo $service['id']; ?>" 
                                data-name="<?php echo htmlspecialchars($service['name']); ?>" 
                                data-price="<?php echo $service['price']; ?>">
                                
                                <div class="service-image">
                                    <?php if (!empty($service['image_path'])): ?>
                                        <img src="../<?php echo $service['image_path']; ?>" alt="<?php echo htmlspecialchars($service['name']); ?>">
                                    <?php else: ?>
                                        <img src="/placeholder.svg?height=150&width=200" alt="<?php echo htmlspecialchars($service['name']); ?>">
                                    <?php endif; ?>
                                </div>
                                
                                <div class="service-info">
                                    <h3><?php echo htmlspecialchars($service['name']); ?></h3>
                                    <p><?php echo htmlspecialchars($service['description']); ?></p>
                                    <div class="service-price">₱<?php echo number_format($service['price'], 2); ?></div>
                                </div>
                                
                                <button class="add-to-cart-btn">Add to Cart</button>
                            </div>
                        <?php 
                            endforeach;
                        else:
                        ?>
                            <div class="no-services">
                                <p>No services available in this category.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <!-- Fallback content if no categories are found -->
            <div class="category-content active" id="all-content">
                <div class="subcategory-grid">
                    <div class="service-card" data-id="1" data-name="Women's Haircut" data-price="45">
                        <div class="service-image">
                            <img src="/placeholder.svg?height=150&width=200" alt="Women's Haircut">
                        </div>
                        <div class="service-info">
                            <h3>Women's Haircut</h3>
                            <p>Professional haircut for women of all hair lengths.</p>
                            <div class="service-price">$45</div>
                        </div>
                        <button class="add-to-cart-btn">Add to Cart</button>
                    </div>
                    <!-- More fallback services would go here -->
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Include the external JavaScript file -->
<script src="../assets/js/services.js"></script>
