<?php
// Start session
session_start();

// Set headers for JSON response
header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION["user_id"])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit;
}

// Include database connection
include "../../login_register/tools/salondb.php";
$pdo = getDatabaseConnection('pdo');nection();

// Get action from request
$action = isset($_GET['action']) ? $_GET['action'] : '';

// Handle different actions
switch ($action) {
    case 'get':
        getUserProfile();
        break;
    case 'update':
        updateUserProfile();
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
        break;
}

// Get user profile
function getUserProfile() {
    global $dbConnection;
    $user_id = $_SESSION['user_id'];
    
    try {
        $stmt = $dbConnection->prepare("SELECT first_name, last_name, email, phone, address, created_at FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            echo json_encode(['success' => true, 'user' => $user]);
        } else {
            echo json_encode(['success' => false, 'message' => 'User not found']);
        }
        
        $stmt->close();
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Error fetching user profile: ' . $e->getMessage()]);
    }
}

// Update user profile
function updateUserProfile() {
    global $dbConnection;
    $user_id = $_SESSION['user_id'];
    
    // Get JSON data from request body
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!$data) {
        echo json_encode(['success' => false, 'message' => 'Invalid data']);
        return;
    }
    
    try {
        $stmt = $dbConnection->prepare("
            UPDATE users 
            SET first_name = ?, 
                last_name = ?, 
                phone = ?, 
                address = ? 
            WHERE id = ?
        ");
        
        $stmt->bind_param("ssssi", 
            $data['first_name'], 
            $data['last_name'], 
            $data['phone'], 
            $data['address'], 
            $user_id
        );
        
        if ($stmt->execute()) {
            // Update session variables
            $_SESSION['first_name'] = $data['first_name'];
            $_SESSION['last_name'] = $data['last_name'];
            $_SESSION['phone'] = $data['phone'];
            $_SESSION['address'] = $data['address'];
            
            echo json_encode(['success' => true, 'message' => 'Profile updated successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Error updating profile: ' . $dbConnection->error]);
        }
        
        $stmt->close();
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Error updating profile: ' . $e->getMessage()]);
    }
}
?>
